package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity(), View.OnClickListener {
    private val TAG = "MainActivity"
    var PLAYER = true
    var TURN_COUNT = 0

    var board_Status = Array(3) { IntArray(3)}

    lateinit var board: Array<Array<Button>>
    lateinit var btn1: Button
    lateinit var btn2: Button
    lateinit var btn3: Button
    lateinit var btn4: Button
    lateinit var btn5: Button
    lateinit var btn6: Button
    lateinit var btn7: Button
    lateinit var btn8: Button
    lateinit var btn9: Button
    lateinit var rbtn: Button
    lateinit var displayTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btn1 = findViewById(R.id.button1)
        btn2 = findViewById(R.id.button2)
        btn3 = findViewById(R.id.button3)
        btn4 = findViewById(R.id.button4)
        btn5 = findViewById(R.id.button5)
        btn6 = findViewById(R.id.button6)
        btn7 = findViewById(R.id.button7)
        btn8 = findViewById(R.id.button8)
        btn9 = findViewById(R.id.button9)
        rbtn = findViewById(R.id.resetbtn)
        displayTv = findViewById(R.id.displayTv)
        board = arrayOf(
            arrayOf(btn1, btn2, btn3),
            arrayOf(btn4, btn5, btn6),
            arrayOf(btn7, btn8, btn9)
        )
        for (i in board) {
            for (button in i) {
                button.setOnClickListener(this)
            }
        }
        initializeBoardStatus()
        rbtn.setOnClickListener {
            PLAYER = true
            TURN_COUNT = 0
            initializeBoardStatus()
        }
    }

    private fun initializeBoardStatus() {
        updateDisplay("player X turn")
        for (i in 0..2){
            for (j in 0..2){
                board_Status[i][j]=-1
            }
        }
        for (i in board) {
            for (button: Button in i) {

                button.isEnabled = true
                button.text = ""
            }
        }
    }

    override fun onClick(view: View?) {
        if (view != null) {
            when (view.id) {
                R.id.button1 -> {
                    updatevalue(row = 0, col = 0, player = PLAYER)
                }
                R.id.button2 -> {
                    updatevalue(row = 0, col = 1, player = PLAYER)
                }
                R.id.button3 -> {
                    updatevalue(row = 0, col = 2, player = PLAYER)
                }
                R.id.button4 -> {
                    updatevalue(row = 1, col = 0, player = PLAYER)
                }
                R.id.button5 -> {
                    updatevalue(row = 1, col = 1, player = PLAYER)
                }
                R.id.button6 -> {
                    updatevalue(row = 1, col = 2, player = PLAYER)
                }
                R.id.button7 -> {
                    updatevalue(row = 2, col = 0, player = PLAYER)
                }
                R.id.button8 -> {
                    updatevalue(row = 2, col = 1, player = PLAYER)
                }
                R.id.button9 -> {
                    updatevalue(row = 2, col = 2, player = PLAYER)
                }
            }
        }
        TURN_COUNT++
        PLAYER = !PLAYER
        if (PLAYER) {
            updateDisplay("player X turn")
        } else {
            updateDisplay("player O turn")
        }
        if (TURN_COUNT == 9) {
            updateDisplay("game draw")
        }
        println("$board_Status")
        checkWinner()
    }

    private fun checkWinner() {
        //horizontal rows
        for (i in 0..2) {
            if (board_Status[i][0] == board_Status[i][1] && board_Status[i][0] == board_Status[i][2]) {

                if (board_Status[i][0] == 1) {
                    updateDisplay("Player X is winner")

                    break
                } else if (board_Status[i][0] == 0) {
                    updateDisplay("Player O is winner")
                    break
                }
            }

        }
        //vertical columns
        for (i in 0..2) {
            if (board_Status[0][i] == board_Status[1][i] && board_Status[0][i] == board_Status[2][i]) {

                if (board_Status[0][i] == 1) {
                    updateDisplay("Player X is winner")
                    break
                } else if (board_Status[0][i] == 0) {
                    updateDisplay("Player O is winner")
                    break
                }
            }

        }
        // first diagonal
        if (board_Status[0][0] == board_Status[1][1] && board_Status[0][0] == board_Status[2][2]) {

            if (board_Status[0][0] == 1) {
                updateDisplay("Player X is winner")
            } else if (board_Status[0][0] == 0) {
                updateDisplay("Player O is winner")
            }

        }
        // second diagonal
        if (board_Status[0][2] == board_Status[1][1] && board_Status[0][2] == board_Status[2][0]) {

            if (board_Status[0][2] == 1) {
                updateDisplay("Player X is winner")
            } else if (board_Status[0][2] == 0) {
                updateDisplay("Player O is winner")
            }

        }
    }

    private fun updateDisplay(text: String) {
        displayTv.text = text
        if (text.contains("winner")) {
            disableButton()
        } else {

        }

    }

    private fun disableButton() {
        for (i in board) {
            for (button: Button in i) {
                button.isEnabled = false
            }
        }
    }

    private fun updatevalue(row: Int, col: Int, player: Boolean) {
        val text: String = if (player) "X" else "O"
        val value: Int = if (player) 1 else 0
        board[row][col].apply {
            isEnabled = false
            setText(text)
        }
        board_Status[row][col] = value
    }
}